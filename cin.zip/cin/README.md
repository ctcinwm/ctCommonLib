# cyndatec
This project support common libraries which can used for the clients 

At this moment it is supporting FX servivce based on Swiss Fed

