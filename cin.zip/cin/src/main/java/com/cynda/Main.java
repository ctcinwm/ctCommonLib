package com.cynda;

import com.cynda.fx.service.SwissExchangeServiceImpl;
import org.xml.sax.SAXException;

import javax.xml.parsers.ParserConfigurationException;
import java.io.IOException;
import java.time.LocalDate;

public class Main {

    public static void main(String[] args) throws ParserConfigurationException, IOException, SAXException {

        System.out.println(LocalDate.now());
//        System.out.println(SwissExchangeServiceImpl.getDailyRate());
//        System.out.println(SwissExchangeServiceImpl.getMonthlyAvgRate());
        System.out.println(SwissExchangeServiceImpl.getMonthlyAvgRate(2025, 2));


    }
}