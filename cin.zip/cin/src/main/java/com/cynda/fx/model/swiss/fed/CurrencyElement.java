package com.cynda.fx.model.swiss.fed;

import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import java.math.BigDecimal;
import java.math.MathContext;

public class CurrencyElement {

    public static final String ELEMENT_DEVISE = "devise";
    public static final String ELEMENT_LAND = "land_en";
    // from currency String
    public static final String ELEMENT_WAHRUNG_FROM_CURRENCY = "waehrung";
    //kurs
    public static final String ELEMENT_KURS_CHF_VALUE = "kurs";

    public static final String ATTRIBUTE_CODE = "code";


    private String fromCurrency;
    private static final  String toCurrency = "CHF";

    private String land;

    private BigDecimal fromCurrencyValue;
    private BigDecimal toCurrencyValue;

    public String getFromCurrency() {
        return fromCurrency;
    }

    public void setFromCurrency(String fromCurrency) {
        this.fromCurrency = fromCurrency;
    }

    public String getLand() {
        return land;
    }

    public void setLand(String land) {
        this.land = land;
    }

    public BigDecimal getFromCurrencyValue() {
        return fromCurrencyValue;
    }

    public void setFromCurrencyValue(BigDecimal fromCurrencyValue) {
        this.fromCurrencyValue = fromCurrencyValue;
    }

    public BigDecimal getToCurrencyValue() {
        return toCurrencyValue;
    }

     private BigDecimal rate;

    public void setRate(BigDecimal rate) {
        this.rate = rate;
    }

    public BigDecimal getRate() {
        this.rate = new BigDecimal(1);
        if(null != this.getFromCurrencyValue() && this.getFromCurrencyValue().doubleValue() > 0) {
            double x =  this.getToCurrencyValue().doubleValue() / this.getFromCurrencyValue().doubleValue();
           this.rate =  new BigDecimal(x);
        }
        return rate;
    }
    public void setToCurrencyValue(BigDecimal toCurrencyValue) {
        this.toCurrencyValue = toCurrencyValue;
    }
    public void setToCurrencyValue(String toCurrencyValue) {
        if (null != toCurrencyValue) {
            this.toCurrencyValue = new BigDecimal(toCurrencyValue);
        }
    }

    /*
        <devise code="eur">
            <land_de>Europäische Währungsunion</land_de>
            <land_fr>Union monétaire européenne</land_fr>
            <land_it>Unione Monetaria Europea</land_it>
            <land_en>Euro Member</land_en>
            <waehrung>1 EUR</waehrung>
              <kurs>1.01340</kurs>
         */
    public static CurrencyElement getCurrencyElement(Node devNode){
          CurrencyElement  devCurrObj = new CurrencyElement();
          if(null != devNode && ELEMENT_DEVISE.equalsIgnoreCase(devNode.getNodeName())){

                devCurrObj.setFromCurrency(devNode.getAttributes().getNamedItem(ATTRIBUTE_CODE).getTextContent());
              int dailyNodeLength = devNode.getChildNodes().getLength();
              NodeList parentNodeList = devNode.getChildNodes();

              for ( int i= 0;i < dailyNodeLength; i++){
                  Node childNode = parentNodeList.item(i);
                  switch (childNode.getNodeName().toLowerCase()) {
                      case ELEMENT_LAND -> devCurrObj.setLand(childNode.getTextContent());
                      case ELEMENT_WAHRUNG_FROM_CURRENCY -> devCurrObj.setFromCurrencyValue(getSourceCurrencyValue(childNode.getTextContent()));
                      case ELEMENT_KURS_CHF_VALUE -> devCurrObj.setToCurrencyValue(childNode.getTextContent());
                      default -> System.out.println(childNode.getNodeName() );

                   }
                }
          }
        System.out.print("----");
        System.out.println(devCurrObj);
        return  devCurrObj;
    }



        private static BigDecimal getSourceCurrencyValue(String nodeValue){
            BigDecimal result = null;
            try {
                if (null != nodeValue) {
                    String[] fromCurrency = nodeValue.split(" ");
                    result =  new BigDecimal(fromCurrency[0]);
                }

            }catch (Exception e) {
                System.out.println("-------GO TO Bed-----------------");;
                e.printStackTrace();
            }
            return result;

        }



    @Override
    public String toString() {
        return "CurrencyElement{" +
                "fromCurrency='" + fromCurrency + '\'' +
                ", land='" + land + '\'' +
                ", fromCurrencyValue=" + fromCurrencyValue +
                ", toCurrencyValue=" + toCurrencyValue +
                '}';
    }
}
