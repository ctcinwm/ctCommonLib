package com.cynda.fx.model.swiss.fed;

import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import java.util.ArrayList;
import java.util.List;

public class SwissGovDailyRate {
    public static final String  ELEMENT_ROOT = "wechselkurse";
    public static final String  ELEMENT_PERIOD = "datum";

    public static final String  ELEMENT_PREPARED_TIME = "zeit";

    public static final String  ELEMENT_VALID_UNTIL_PERIOD = "gueltigkeit";

    public static final  String  RATE_TYPE = "Daily";

    public static final String TO_CURRENCY = "CHF";

    private String  period;
    private String validUntilPeriod;

    private String preparedTime;

    private List<CurrencyElement> currencyList;

    public List<CurrencyElement> getCurrencyList() {
        return currencyList;
    }

    public void setCurrencyList(List<CurrencyElement> currencyList) {
        this.currencyList = currencyList;
    }





    public String getPeriod() {
        return period;
    }

    public void setPeriod(String period) {
        this.period = period;
        setYearMonthDay(period);
    }

    private void setYearMonthDay(String period) {
        String[] sd = period.split("\\.");
        if(sd.length == 3) {
            setYear(Integer.valueOf(sd[2]));
            setMonth(Integer.valueOf(sd[1]));
            setDay(Integer.valueOf(sd[0]));
        }

    }

    private void setDay(Integer day) {
        this.day = day;
    }

    private void setMonth(Integer mon) {
        this.month = mon;
    }

    private void setYear(Integer year) {
        this.year = year;
    }

    public String getValidUntilPeriod() {
        return validUntilPeriod;
    }

    public void setValidUntilPeriod(String validUntilPeriod) {
        this.validUntilPeriod = validUntilPeriod;
    }

    public String getPreparedTime() {
        return preparedTime;
    }

    public void setPreparedTime(String preparedTime) {
        this.preparedTime = preparedTime;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    private String status;

    private int year;
    private int month;
    private int day;

    public int getYear() {
        return year;
    }

    public int getMonth() {
        return month;
    }

    public int getDay() {
        return day;
    }

    public static SwissGovDailyRate getValue(Node devNode){
        SwissGovDailyRate devCurrObj = new SwissGovDailyRate();
        if(null != devNode && ELEMENT_ROOT.equalsIgnoreCase(devNode.getNodeName())){
            System.out.println( " Daily Node============GovernmentDailyRate=================");

            NodeList parentNodeList = devNode.getChildNodes();
            int dailyNodeLength = parentNodeList.getLength();

            List<CurrencyElement> currencyElements = new ArrayList<CurrencyElement>();
            for ( int i= 0;i < dailyNodeLength; i++){
                Node childNode = parentNodeList.item(i);
                switch (childNode.getNodeName().toLowerCase()) {
                    case ELEMENT_PERIOD -> devCurrObj.setPeriod(childNode.getTextContent());
                    case ELEMENT_PREPARED_TIME -> devCurrObj.setPreparedTime(childNode.getTextContent());
                    case ELEMENT_VALID_UNTIL_PERIOD -> devCurrObj.setValidUntilPeriod(childNode.getTextContent());
                    case CurrencyElement.ELEMENT_DEVISE -> currencyElements.add(CurrencyElement.getCurrencyElement(childNode));
                    default -> System.out.println(childNode.getNodeName()+"----"+childNode.getNodeValue());
                }

            }

            devCurrObj.setCurrencyList(currencyElements);
        }
        return  devCurrObj;

    }

    @Override
    public String toString() {
        return "SwissGovDailyRate{" +
                "period='" + period + '\'' +
                ", validUntilPeriod='" + validUntilPeriod + '\'' +
                ", preparedTime='" + preparedTime + '\'' +
                ", currencyList=" + currencyList +
                ", status='" + status + '\'' +
                ", year=" + year +
                ", month=" + month +
                ", day=" + day +
                '}';
    }
}
