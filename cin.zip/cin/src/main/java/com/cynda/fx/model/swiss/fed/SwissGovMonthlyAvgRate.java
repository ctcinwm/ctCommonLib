package com.cynda.fx.model.swiss.fed;

import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import java.util.ArrayList;
import java.util.List;
public class SwissGovMonthlyAvgRate {
    public static final String  ELEMENT_ROOT = "monatsmittelkurs";
    public static final String  ELEMENT_PERIOD = "monat";


    private static final  String  fxRateType = "Monthly-Aggregated";

    private String  period;


    private List<CurrencyElement> currencyList;

    public List<CurrencyElement> getCurrencyList() {
        return currencyList;
    }

    public void setCurrencyList(List<CurrencyElement> currencyList) {
        this.currencyList = currencyList;
    }

    public String getPeriod() {
        return period;
    }

    public void setPeriod(String period) {
        this.period = period;
    }

    public static String getFxRateType() { return fxRateType;}


    private String status;
    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public static SwissGovMonthlyAvgRate getCurrencyElement(Node devNode){
        SwissGovMonthlyAvgRate devCurrObj = new SwissGovMonthlyAvgRate();
        if(null != devNode && ELEMENT_ROOT.equalsIgnoreCase(devNode.getNodeName())){
            System.out.println( " Daily Node============GovernmentDailyRate=================");

            NodeList parentNodeList = devNode.getChildNodes();
            int dailyNodeLength = parentNodeList.getLength();

            List<CurrencyElement> currencyElementList = new ArrayList<CurrencyElement>();
            for ( int i= 0;i < dailyNodeLength; i++){
                Node childNode = parentNodeList.item(i);
                switch (childNode.getNodeName().toLowerCase()) {
                    case ELEMENT_PERIOD -> devCurrObj.setPeriod(childNode.getTextContent());
                    case CurrencyElement.ELEMENT_DEVISE -> currencyElementList.add(CurrencyElement.getCurrencyElement(childNode));
                    default -> System.out.println(childNode.getNodeName()+"----"+childNode.getNodeValue());

                }

            }
            devCurrObj.setCurrencyList(currencyElementList);
        }
        return  devCurrObj;

    }

    @Override
    public String toString() {
        return "GovMonthlyAvgFxRate{" +
                "period='" + period + '\'' +
                ", currencyList=" + currencyList +
                ", status='" + status + '\'' +
                '}';
    }
}
