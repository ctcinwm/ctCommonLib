package com.cynda.fx.service;

import com.cynda.fx.model.swiss.fed.SwissGovDailyRate;
import com.cynda.fx.model.swiss.fed.SwissGovMonthlyAvgRate;

public class  ExchangeService {



    public static SwissGovMonthlyAvgRate getMonthlyAvgRate(int year , int month){
        return SwissExchangeServiceImpl.getMonthlyAvgRate(year, month);
    }


    public static SwissGovMonthlyAvgRate getMonthlyAvgRate(){
        return SwissExchangeServiceImpl.getMonthlyAvgRate();
    }
    public static SwissGovDailyRate getDailyRate(){
        return SwissExchangeServiceImpl.getDailyRate();
    }
    public static SwissGovDailyRate getDailyRate(int dateYYYYMMDD){
        return SwissExchangeServiceImpl.getDailyRate(dateYYYYMMDD);
    }


}
