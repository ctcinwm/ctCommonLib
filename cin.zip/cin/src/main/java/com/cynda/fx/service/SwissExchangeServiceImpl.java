package com.cynda.fx.service;


import com.cynda.fx.model.swiss.fed.SwissGovDailyRate;
import com.cynda.fx.model.swiss.fed.SwissGovMonthlyAvgRate;
import org.w3c.dom.Document;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import java.io.IOException;

public class SwissExchangeServiceImpl {


    private static final String   FX_RATE_DAILY_API_URL = "https://www.backend-rates.bazg.admin.ch/api/xmldaily";


    private static final String FX_RATE_MONTHLY_DEFAULT_API_URL = "https://www.backend-rates.bazg.admin.ch/api/xmlavgmonth";

    private static  Document getDocument(String url) throws IOException, SAXException, IllegalArgumentException, ParserConfigurationException
    {
        DocumentBuilder builder = DocumentBuilderFactory.newInstance().newDocumentBuilder();
        Document doc = builder.parse(url);
        doc.getDocumentElement().normalize();

        return  doc;
    }

    public static SwissGovDailyRate getDailyRate(int dateYYYXMMDD){
        SwissGovDailyRate dailyRate = null;
        try {

            Document doc = getDocument(FX_RATE_DAILY_API_URL+"?d="+dateYYYXMMDD);
            NodeList nodeList = doc.getElementsByTagName(SwissGovDailyRate.ELEMENT_ROOT);
            Node root = nodeList.item(0);
            dailyRate = SwissGovDailyRate.getValue(root);

            dailyRate.setStatus("Success -> Swiss Fed Date "+dailyRate.getStatus()+" Processed");

        }
        catch(Exception e) {
            dailyRate = new SwissGovDailyRate();
            dailyRate.setStatus("Error -> Unexpected problem. While loading for date"+dateYYYXMMDD+" Contact Support \n"+e.getMessage());

        }
        return dailyRate;

    }


    public static SwissGovDailyRate getDailyRate(){
        SwissGovDailyRate dailyRate = null;
        try {

            Document doc = getDocument(FX_RATE_DAILY_API_URL);
            NodeList nodeList = doc.getElementsByTagName(SwissGovDailyRate.ELEMENT_ROOT);
            Node root = nodeList.item(0);
            dailyRate = SwissGovDailyRate.getValue(root);
            dailyRate.setStatus("Success -> Swiss Fed Date "+dailyRate.getStatus()+" Processed");

        }
        catch(Exception e) {
            dailyRate = new SwissGovDailyRate();
            dailyRate.setStatus("Error -> Unexpected problem. Contact Support \n"+e.getMessage());

        }
        return dailyRate;

    }

    private  static SwissGovMonthlyAvgRate getMonthlyAvgRate(Document doc){
        SwissGovMonthlyAvgRate monthlyAvgRate                = null;

        try {

            NodeList nodeList = doc.getElementsByTagName(SwissGovMonthlyAvgRate.ELEMENT_ROOT);
            Node root = nodeList.item(0);
            monthlyAvgRate = SwissGovMonthlyAvgRate.getCurrencyElement(root);
            monthlyAvgRate.setStatus("Success -> Swiss Fed Date "+monthlyAvgRate.getPeriod()+" Processed");

        }
        catch(Exception e) {
            monthlyAvgRate = new SwissGovMonthlyAvgRate();
            monthlyAvgRate.setStatus("Error -> Unexpected problem. Contact Support \n"+e.getMessage());

        }
        return monthlyAvgRate;


    }

    public static SwissGovMonthlyAvgRate getMonthlyAvgRate(int year , int month){
        SwissGovMonthlyAvgRate monthlyAvgRate = null;
        try {

            //?j=2022&m=12
            Document doc = getDocument(FX_RATE_MONTHLY_DEFAULT_API_URL + "?j=" + year + "&m=" + month);
            monthlyAvgRate =  getMonthlyAvgRate(doc);


        }
        catch(Exception e) {
            monthlyAvgRate = new SwissGovMonthlyAvgRate();
            String message = String.format("Information is NOT AVAILABLE for the Year %d and Month %d", year, month
            );
            monthlyAvgRate.setStatus("Error -> "+message);
            e.printStackTrace();

        }
        return monthlyAvgRate;

    }

    public static SwissGovMonthlyAvgRate getMonthlyAvgRate(){
        SwissGovMonthlyAvgRate monthlyAvgRate = null;
        try {

            //?j=2022&m=12
            Document doc = getDocument(FX_RATE_MONTHLY_DEFAULT_API_URL);
            monthlyAvgRate =  getMonthlyAvgRate(doc);

        }
        catch(Exception e) {
            monthlyAvgRate = new SwissGovMonthlyAvgRate();
            monthlyAvgRate.setStatus("Error -> Unexpected problem. Contact Support \n"+e.getMessage());
            e.printStackTrace();

        }
        return             monthlyAvgRate;



    }


}
